<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Portal Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the Portal.
    |
    */

    'Dashboard' => 'Dashboard',
    'Offices' => 'Offices',
    'Add' => 'Add',
    'View' => 'View',
    'Employees' => 'Employees',
    'Schedules' => 'Schedules',
    'Reports' => 'Reports',
    'Business' => 'Business',
    'Logout' => 'Logout',

];
