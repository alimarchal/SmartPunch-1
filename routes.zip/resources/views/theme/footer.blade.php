<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <?php echo date("Y");?> &copy; <a class="text-blue">{{__('portal.SmartPunch')}}</a>
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="javascript:void(0);">{{__('portal.About Us')}}</a>
                    <a href="javascript:void(0);">{{__('portal.Help')}}</a>
                    <a href="javascript:void(0);">{{__('portal.Contact Us')}}</a>
                </div>
            </div>
        </div>
    </div>
</footer>
